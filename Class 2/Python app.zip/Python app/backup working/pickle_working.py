# Resize the Window - Non Pep8 Compliant, mandated by Kivy
from kivy.config import Config
Config.set('graphics', 'width', '400')
Config.set('graphics', 'height', '200')

from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.properties import StringProperty
import pickle

import speech_recognition as sr

r = sr.Recognizer()
m = sr.Microphone()
'''
quest = ['What is your name?', 'How old are you?', 'How many years of experience do you have',
         'How many years of education do you have?', 'Did you find a job after graduation?']
i = 0
'''
# Root Widget
class Root(BoxLayout):
    pass


class RecordButton(Button):
    # String Property to Hold output for publishing by Textinput
    text_arr = []
    output = StringProperty('')

    def addText(self, text):
        self.text_arr.append(text)


    def updateText(self):
        self.output = "\n".join(self.text_arr)
    
    def record(self):
        # GUI Blocking Audio Capture
        with m as source:
            audio = r.listen(source)
        
        try:
            # recognize speech using Google Speech Recognition
            value = r.recognize_google(audio)
            self.addText("You said \"{}\"".format(value))
            self.updateText()
           ##
            #path_to_file = "/Users/thomaskurnicki/Desktop/Text analytics class/Python code for speach recognition/test_data.txt"
            #data_file = open(path_to_file, 'r')
            #array = self.text_arr

            #for row in data_file:
            #    array.append(row)

            #write = array.write(path_to_file)
            #print(array)
            #array.write(path_to_file)

            #newstr = '\n'.join([''.join(i) for i in items if i[1] in array])
            myoutput = self.output
            with open("myfile.pkl", 'wb') as f:
                pickle.dump(myoutput,f)
            #data_file.close()
        ###
        except sr.UnknownValueError:
            self.addText("Oops! Didn't catch that")
        
        except sr.RequestError as e:
            self.addText("Uh oh! Couldn't request results from Google Speech Recognition service; {0}".format(e))


class SpeechApp(App):
    def build(self):
        # Calibrate the Microphone to Silent Levels
        print("A moment of silence, please...")
        with m as source:
            r.adjust_for_ambient_noise(source)
            print("Set minimum energy threshold to {}".format(r.energy_threshold))
        # Create a root widget object and return as root
        return Root()


# When Executed from the command line (not imported as module), create a new SpeechApp
if __name__ == '__main__':
    SpeechApp().run()

