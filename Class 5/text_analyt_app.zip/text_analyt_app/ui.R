#
# This is the user-interface definition of a Shiny web application. You can
# run the application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
# 
#    http://shiny.rstudio.com/
#

library(shiny)

# Define UI for application that draws a histogram
shinyUI(fluidPage(
  
  # Application title
  titlePanel("xxxxxxxxxx"),
  
  # Sidebar with a slider input for number of bins 
  sidebarLayout(
    sidebarPanel(
      textInput("xxxxxxxxxx", label = h3("xxxxxxxxx"), value = "xxxxxxxx"),
      textInput("xxxxxxxxxx", label = h3("xxxxxxxxxx"), value="xxxxxxxxxx"),
      textInput("xxxxxxxxxx", label=h3("xxxxxxxxxxxxx"), value="xxxxxxxxx" ),
      textInput("xxxxxxxxxx", label=h3("xxxxxxxxxxx"), value="xxxxxxxxx"),
      textInput("xxxxxxxxx", label=h3("xxxxxxxxxxxx"), value="xxxxxxxxxx")
    ),
    
    # Show a plot of the generated distribution
    mainPanel(
      tabsetPanel(
        tabPanel("Wordcloud", plotOutput("distPlot",  width = "100%", height = "1000px")),
        tabPanel("N-Gram", plotOutput("ngram",  width = "100%", height = "1000px")),
        tabPanel("Correlograms", plotOutput("correlation",  width = "100%", height = "1000px"))
      )
    
    )
  )
))
