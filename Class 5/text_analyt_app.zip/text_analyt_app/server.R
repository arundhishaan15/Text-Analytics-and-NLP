
library(shiny)

# Define server logic required to draw a histogram
shinyServer(function(input, output) {
   
  library("twitteR")
  library("tm")
  
  #necessary file for Windows
  setwd("xxxxxxxxxx")
  #download.file(url="http://curl.haxx.se/ca/cacert.pem", destfile="cacert.pem")
  
  #to get your consumerKey and consumerSecret see the twitteR documentation for instructions
  consumer_key <- 'xxxxxxxxx'
  consumer_secret <- 'xxxxxxxxx'
  access_token <- 'xxxxxxxxxx'
  access_secret <- 'xxxxxxxx'

  
  output$distPlot <- renderPlot({
    
    setup_twitter_oauth(consumer_key, consumer_secret, access_token, access_secret)
    USA <- twitteR::searchTwitter(paste(xxxxxxxxxxxx, "+", xxxxxxxxx), n = 1000, since = '2015-06-01', retryOnRateLimit = 1e3)
    d <<- twitteR::twListToDF(USA)
    ##############################################
    ### Sentiment wordclounds for USA ############
    ##############################################
    
    tidy_usa <- d %>%
      unnest_tokens(word, text) %>%
      inner_join(get_sentiments("bing")) %>%
      count(word, sentiment, sort=T) %>%
      ungroup()
    
    tidy_usa #look at trump - he is positive!!! :)
    
    tidy_usa %>%
      group_by(sentiment) %>%
      top_n(10) %>%
      ungroup() %>%
      mutate(word=reorder(word, n)) %>%
      ggplot(aes(word, n, fill=sentiment)) +
      geom_col(show.legend = FALSE) +
      facet_wrap(~sentiment, scales = "free_y")+
      labs(y="Contribution to sentiment", x=NULL)+
      coord_flip()
    
    library(reshape2)
    #we need to use the NRC sentiments
    tidy_usa %>%
      inner_join(get_sentiments("nrc")) %>%
      count(word, sentiment, sort=TRUE) %>%
      acast(word ~sentiment, value.var="nn", fill=0) %>%
      comparison.cloud(colors = c("grey20", "gray80"),
                       max.words=100)
    
    
  }) #closing wordcloud renderPlot
  
  #############################################
  ###### N-grams and tokenizing ###############
  #############################################
  
  library(dplyr)
  library(tidytext)
  library(janeaustenr)
  library(tidyr)
  
  my_bigrams <- d %>%
    unnest_tokens(bigram, text, token = "ngrams", n=2)
  
  my_bigrams #We want to see the bigrams (words that appear together, "pairs")
  
  my_bigrams %>%
    count(bigram, sort = TRUE) #this has many stop words, need to remove them 
  
  #to remove stop words from the bigram data, we need to use the separate function:
  library(tidyr)
  bigrams_separated <- my_bigrams %>%
    separate(bigram, c("word1", "word2"), sep = " ")
  
  bigrams_filtered <- bigrams_separated %>%
    filter(!word1 %in% stop_words$word) %>%
    filter(!word2 %in% stop_words$word)
  
  #creating the new bigram, "no-stop-words":
  bigram_counts <- bigrams_filtered %>%
    count(word1, word2, sort = TRUE)
  
  output$ngram <- renderPlot({
    
    ######################################################
    ####### VISUALISING A BIGRAM NETWORK #################
    ######################################################
    
    #install.packages("igraph")
    library(igraph)
    bigram_graph <- bigram_counts %>%
      filter(n>20) %>%
      graph_from_data_frame()
    
    
    #install.packages("ggraph")
    library(ggraph)
    ggraph(bigram_graph, layout = "fr") +
      geom_edge_link()+
      geom_node_point()+
      geom_node_text(aes(label=name), vjust =1, hjust=1)
    
  })#closing the n-gram renderPlot
  
  ################################################
  ###Pairwise correlations between words #########
  ################################################
  
  #install.packages("widyr")
  library(widyr)
  library(janeaustenr)
  library(tidyr)
  library(dplyr)
  my_tidy_df <- d %>%
    unnest_tokens(word, text) %>%
    filter(!word %in% stop_words$word)
  
  my_tidy_df
  #taking out the least common words
  word_cors <- my_tidy_df %>%
    group_by(word) %>%
    filter(n() >= 1) %>%
    pairwise_cor(word,retweetCount, sort=TRUE) #changed "section" to "retweetCount" 
  #pairwise_cor() check correlation based on how ofter words appear in the same section
  
  output$correlation <- renderPlot({
    
    word_cors %>%
      filter(item1 %in% c(xxxxxxxxxxxxxxx, xxxxxxxxxxxxx, xxxxxxxxxxxxx)) %>%
      group_by(item1) %>%
      top_n(6) %>%
      ungroup() %>%
      mutate(item2 = reorder(item2, correlation)) %>%
      ggplot(aes(item2, correlation)) +
      geom_bar(stat = "identity")+
      facet_wrap(~item1, scales = "free")+
      coord_flip()
    
  })#closing the correlation renderPlot

  
})
